
I2S Support for different processor architectures