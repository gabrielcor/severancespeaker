
These folder contains some work in progress, experiments and tests, so do not expect them to work!

But it might still serve as a source of inspiration...