
This directory contains a server in Python that was used to test the [Arduino
post sketch](https://github.com/pschatzmann/arduino-audio-tools/blob/main/examples/examples-communication/http-client/streams-http_post/streams-http_post.ino) using chunged writes.

The server logs each written line and writes the data to a file.
