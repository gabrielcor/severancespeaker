# A Simple Streaming Audio Player

This is just a simple example which demonstrates how to use your own subclasses to add additional functionality.

We provide the URL ICY parameters in our own AudioSourceIcyUrl subclass!

### Dependencies

- https://github.com/pschatzmann/arduino-audio-tools
- https://github.com/pschatzmann/arduino-libhelix
